
#ifndef H_MERGESORT_
#define H_MERGESORT_

	#include <stdio.h>

	void MS_sort(void *, unsigned long, size_t, int (*)(const void *, const void *));

#endif