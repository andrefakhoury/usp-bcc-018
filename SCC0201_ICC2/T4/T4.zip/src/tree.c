// #include "tree.h"

// #include <stdlib.h>
// #include <stdio.h>

// typedef struct node {
// 	double val;
// 	char op;
// 	node *left, *right;
// } node;

// struct tree {
// 	node* root;
// };

// double numFromString(char* s) {
// 	char temp[MAXOPERATION];
// 	for (int i = 0; s[i] != ' ' && s[i] != '\0'; i++)
// 		temp[i] = s[i];
// 	double ret;
// 	sscanf(temp, "%lf", &ret);
// 	return ret;
// }

// tree* buildTree(char* s) {
// 	for (int i = 0; s[i] != '\0'; i++) {
		
// 	}
// }

// double solveAndFreeTree(tree* t) {
// 	return 1;
// }