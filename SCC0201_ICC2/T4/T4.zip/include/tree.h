// #ifndef TREE_H
// #define TREE_H

// typedef struct tree tree;

// tree* buildTree(char*);
// double solveAndFreeTree(tree*);

// #endif