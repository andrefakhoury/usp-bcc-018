#ifndef TAB_H
#define TAB_H

typedef struct tab {
	char titulo[32];
	char sitio[1024];
	int dia, mes;
	int hora, min;
} tab;

#endif
