Para executar o arquivo fonte src.py é necessária a instalação da biblioteca ortools.

O código foi feito utilizando-se Python3.8.

Logo, para a sua execução, basta executar:
    python3 src.py

Em algum interpretador python3.
