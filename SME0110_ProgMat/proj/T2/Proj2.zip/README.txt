Tudo referente ao código fonte está na pasta /source !

Desenvolvimento
- O arquivo fonte python é o src.py
- O código foi feito utilizando-se Python3.8.
- Para executar o arquivo fonte src.py é necessária a instalação da biblioteca ortools

Execução
- Basta executá-lo como arquivo python3:
    python3 src.py
- Os arquivos das instâncias estão na pasta /data
- Deve ser criada uma pasta img/ para guardar os gráficos com os caminhos encontrados pelas instãncias
- Os resultados obtidos (texto) serão salvos em arquivos .csv (um arquivo para greedy e um para random, de acordo com as heurísticas utilizadas)
