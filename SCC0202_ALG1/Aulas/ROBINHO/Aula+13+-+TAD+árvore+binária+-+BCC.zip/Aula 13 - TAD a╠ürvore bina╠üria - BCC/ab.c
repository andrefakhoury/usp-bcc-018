#include <stdio.h>
#include <stdlib.h>
#include "ab.h"

void cria(AB *a) {
    a->raiz = NULL; // cria uma arvore vazia
    return;
}

void destroiSub(No *p) {
    if (p == NULL)
        return;
    destroiSub(p->esq); // destroi subarvore esquerda
    destroiSub(p->dir); // destroi subarvore direita
    free(p); // apaga o raiz da subarvore
    return;
}

void destroi(AB *a) {
    destroiSub(a->raiz); // inicia recursao
    a->raiz = NULL;
    return;
}

No *buscaSub(No *p, elem x) {
    No *aux;
    if (p == NULL || p->info == x)
        return p; // serve tanto para quando achou como para quando nao achou
    aux = buscaSub(p->esq, x); // busca subarvore esquerda
    return (aux == NULL) ? buscaSub(p->dir, x) : aux;
    // if (aux == NULL)
    //   return buscaSub(p->dir, x);
    // else
    //   return aux;
}

No *busca(AB a, elem x) {
    return buscaSub(a.raiz, x); // inicia recursao
}

int vazia(AB a) {
    return a.raiz == NULL;
}

int insereRaiz(AB *a, elem x) {
    if (a->raiz != NULL)
        return 1; // erro, raiz jah existe
    a->raiz = malloc(sizeof(No));
    if (a->raiz == NULL)
        return 1; // erro, memoria insuficiente
    a->raiz->info = x; // copia informacao
    a->raiz->esq = NULL; // nao tem filho esquerdo
    a->raiz->dir = NULL; // nao tem filho direito
    return 0; // sucesso
}

int insereEsq(AB a, elem x, elem infoPai) {
    No *pai, *novo;
    pai = buscaSub(a.raiz, infoPai); // busca pai
    if (pai == NULL || pai->esq != NULL)
        return 1; // erro, pai nao existe ou jah tem filho esquerdo
    novo = malloc(sizeof(No));
    if (novo == NULL)
        return 1; // erro, memoria insuficiente
    pai->esq = novo; // liga ao pai
    novo->info = x; // copia informacao
    novo->esq = NULL; // nao tem filho esquerdo
    novo->dir = NULL; // nao tem filho direito
    return 0; // sucesso
}

int insereDir(AB a, elem x, elem infoPai) {
    No *pai, *novo;
    pai = buscaSub(a.raiz, infoPai); // busca pai
    if (pai == NULL || pai->dir != NULL)
        return 1; // erro, pai nao existe ou jah tem filho direito
    novo = malloc(sizeof(No));
    if (novo == NULL)
        return 1; // erro, memoria insuficiente
    pai->dir = novo; // liga ao pai
    novo->info = x; // copia informacao
    novo->esq = NULL; // nao tem filho esquerdo
    novo->dir = NULL; // nao tem filho direito
    return 0; // sucesso
}

void imprimeSub(No *p) {
    printf("{");
    if (p != NULL) {
        printf("%c, ", p->info);
        imprimeSub(p->esq);
        printf(", ");
        imprimeSub(p->dir);
    }
    printf("}");
    return;
}

void imprime(AB a) {
    imprimeSub(a.raiz);
    printf("\n");
    return;
}

No *buscaPaiSub(No *p, elem x) {
    No *aux;
    if ( p == NULL ||
         (p->esq != NULL && p->esq->info == x) ||
         (p->dir != NULL && p->dir->info == x))
        return p; // serve tanto para quando achou como para quando nao achou
    aux = buscaPaiSub(p->esq, x); // busca subarvore esquerda
    return (aux == NULL) ? buscaPaiSub(p->dir, x) : aux;
}

No *buscaPai(AB a, elem x) {
    return buscaPaiSub(a.raiz, x); // inicia recursao
}

int alturaSub(No *p) {
    int aesq, adir;
    if (p == NULL)
        return 0; // arvore nula
    aesq = alturaSub(p->esq); // altura da subarvore esquerda
    adir = alturaSub(p->dir); // altura da subarvore direita
    return (aesq > adir)? aesq + 1 : adir + 1;
}

int altura(AB a) {
    return alturaSub(a.raiz); // inicia recursao
}

void preOrdemSub(No *p) {
    if (p != NULL) {
        printf("%c ", p->info); // processa antes de varrer subarvores
        preOrdemSub(p->esq); // varre lado esquerdo
        preOrdemSub(p->dir); // varre lado direito
    }
    return;
}

void preOrdem(AB a) {
    preOrdemSub(a.raiz); // inicia recursao
    printf("\n");
    return;
}

void emOrdemSub(No *p) {
    if (p != NULL) {
        emOrdemSub(p->esq); // varre lado esquerdo
        printf("%c ", p->info); // processa entre uma subarvore e a outra
        emOrdemSub(p->dir); // varre lado direito
    }
    return;
}

void emOrdem(AB a) {
    emOrdemSub(a.raiz); // inicia recursao
    printf("\n");
    return;
}

void posOrdemSub(No *p) {
    if (p != NULL) {
        posOrdemSub(p->esq); // varre lado esquerdo
        posOrdemSub(p->dir); // varre lado direito
        printf("%c ", p->info); // processa apos subarvores
    }
    return;
}

void posOrdem(AB a) {
    posOrdemSub(a.raiz); // inicia recursao
    printf("\n");
    return;
}
