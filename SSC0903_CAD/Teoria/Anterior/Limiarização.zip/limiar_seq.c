#include<stdio.h>
#include<stdlib.h>

int main(int argc,char **argv){
    int lin,col,i,j;// Define as variáveis de índices e dimensões
    double *matriz, limiar; // Define a matriz e o limiar
    
    fscanf(stdin, "%d ", &lin); // Lê a quantidade de linhas da matriz
    fscanf(stdin, "%d\n", &col); // Lê a quantidade de colunas da matriz
    fscanf(stdin, "%lf\n", &limiar); // Lê o valor do limiar

    matriz=(double *)malloc(lin*col * sizeof(double)); // Aloca a matriz
    for(i=0;i<lin;i++){
        for(j=0;j<col;j++){
            fscanf(stdin, "%lf ",&(matriz[i*col+j])); // Lê a matriz
        }
    }

    for(i=0;i<lin*col;i++){ // Aplica o filtro
        if(matriz[i]>limiar)
            matriz[i]=1.0;
        else{
            matriz[i]=0.0;
        }
    }
      
    for(i=0;i<lin;i++){
        for(j=0;j<col;j++){
            printf("%.1lf ",matriz[i*col+j]); // Imprime o vetor em forma de matriz
        }
        printf("\n");
    }

    free(matriz); // Desaloca a matriz
}