#include<stdio.h>

#include<omp.h>

int main(){
   #pragma omp parallel num_threads(4)
   {
       printf("For good luck, Hello World from thread %d. \n", omp_get_thread_num());
       fflush(0);
   }  
}
