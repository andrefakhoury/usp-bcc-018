#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// alguns números perfeitos conhecidos: {6, 28, 496, 8128, 33550336, 8589869056, …}
// 
// 30o. nr perfeito conhecido: 2.658.455.991.569.831.744.645.692.615.953.842.176
//


int main(int argc,char **argv) {
    int i, j;
    int quant_num_perfeitos=0; // Armazenada a quantidade de números perfeitos encontrados
    int *num_perfeitos; // Vetor para armazenar os números perfeitos
    int soma;
    long max;

    FILE *inputfile;
    char *inputfilename;

        
    if (argc < 2)
    {
	printf("Please run with input file name, i.e., num_perf_mpi inputfile.ext\n");
	exit(-1);
    }

    inputfilename = (char*) malloc (256*sizeof(char));
    strcpy(inputfilename,argv[1]);

    if ((inputfile=fopen(inputfilename,"r")) == 0)
    {
	printf("Error openning input file.\n");
	exit(-1);
    }
    
    fscanf(inputfile, "%ld,", &max);  // maximum number to evaluate
    fclose(inputfile);
	
    printf("max=%ld\n", max);
    fflush(0);
    
    num_perfeitos = (int *)malloc(max*sizeof(int)); // Vetor MUITO maior que o necessário

    for (i = 1; i < max; i++){
        soma = 0;
        for (j = 1; j < i; j++){
            if(i%j == 0){
                soma += j;
            }
        }
        if (soma == i){
            num_perfeitos[quant_num_perfeitos]=i;
            quant_num_perfeitos++;
        }
    }
    
    printf("Total perfect numbers:%d\n", quant_num_perfeitos);
    fflush(0);
    for(i=0;i<quant_num_perfeitos;i++)
    {
        printf("%d\n",num_perfeitos[i]);
    }
    printf("\n");
    fflush(0);

    
    return 0;
}
