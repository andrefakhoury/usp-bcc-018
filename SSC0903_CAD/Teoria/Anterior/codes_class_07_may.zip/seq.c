// para compilar: gcc exerc2_seq.c -o exerc2_seq
// para executar: exerc2_seq
//
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <omp.h>

#define N 10

double soma(double *vet) 
{
  int i;
  double sum = .0;

  for(i = 0; i < N; i++) 
  {
    sum = sum + vet[i];
  }
  return(sum);
}

double maximo(double *vet)
{
  int i;
  double max = -1;

  for( i = 0; i < N; i++)
  {
    if (vet[i] > max)
    {
      max = vet[i];
    }
  }
  return(max);
}

double minimo(double *vet)
{
  int i;
  double min = (double)999999999;

  for( i = 0; i < N; i++)
  {
    if (vet[i] < min)
    {
      min = vet[i];
    }
  }
  return(min);
}


double media(double *vet)
{
  int i;
  double sum = .0, avg = .0;

  for(i = 0; i < N; i++) 
  {
    sum += vet[i];
  }
  avg = sum / N;

  return(avg);
}


double desviopadrao(double *vet)
{
  int i;
  double sum = .0, avg = .0, dp= .0, var;

  for(i = 0; i < N; i++) 
  {
    sum += vet[i];
  }
  avg = sum / N;

  sum = .0;
  for(i = 0; i < N; i++)
  {
     sum += pow((vet[i]-avg), 2);
  }
  var = sum / N;
  
  dp = sqrt(var);

  return(dp);
}


int main(void) {
	int i;
	double vet[N];
	double sum, max, min, avg, dp; 
	
	for (i = 0; i < N; i++)
	{
//	    vet[i] = (double) (rand() % 100);
	    vet[i] = N-i;
	}

//	for (i = 0; i < N; i++)
//	{
//	    printf("vet[%d] = %f \n", i, vet[i]);
//	}
	
	sum = soma(vet);

	max = maximo(vet);
	
	min = minimo(vet);
	
	avg = media(vet);

	dp = desviopadrao(vet);

	printf("Soma=%.3f, Máximo=%.3f, Mínimo=%.3f, Media=%.3f, Dsv Padrão=%.3f \n", sum, max, min, avg, dp);	  
	fflush(0);

	return(0);

} // main()
