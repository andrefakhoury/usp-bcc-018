//Sample solution for parallel programming challenge.
//Copyright (C) 2019 Paulo Sérgio Lopes de Souza
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either version 2
//of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, see <http://www.gnu.org/licenses/>.
//
//Last Revision, May 2020 by Paulo Sergio Lopes de Souza.

// alguns números perfeitos conhecidos: {6, 28, 496, 8128, 33550336, 8589869056, …}
// 
// 30o. nr perfeito conhecido: 2.658.455.991.569.831.744.645.692.615.953.842.176
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mpi.h"

int main(int argc,char **argv) {
    int i, j, soma;
    int totalnumperf, quantnumperf=0; // Armazenada a quantidade de números perfeitos encontrados
    int *numperf; // Vetor para armazenar os números perfeitos
    long max;
    
    FILE *inputfile;
    char *inputfilename;
    
    int myrank, numprocs;
    int myrange, mybegin, myend;
    
    int recvcount, sendcount, gatherroot, shift, *localamounts, *gatherrecvbuf, *vetdisplacements, *vetnumperf;
    
    
    if (argc < 2)
    {
	printf("Please run with input file name, i.e., num_perf_mpi inputfile.ext\n");
	exit(-1);
    }

    inputfilename = (char*) malloc (256*sizeof(char));
    strcpy(inputfilename,argv[1]);

    if ((inputfile=fopen(inputfilename,"r")) == 0)
    {
	printf("Error openning input file.\n");
	exit(-1);
    }

    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &myrank );
    MPI_Comm_size( MPI_COMM_WORLD, &numprocs );

    fscanf(inputfile, "%ld,", &max);  // maximum number to evaluate
    fclose(inputfile);
    
    if (myrank == 0)
    {
	printf("max=%ld\n", max);
	fflush(0);
    }
    
    numperf = (int *)malloc(100*sizeof(int)); // Array with 100 positions is enough

    // determine ranges for each process
    myrange = max/numprocs;
    // os primeiros (max%numprocs) processos recebem, cada um, um nr a mais quando a divisao de max / numprocs nao eh exata
    if (myrank < max%numprocs) 
    {
	mybegin = ++myrange * myrank;
    }
    else 
    {
	// it does not increment myrange and shift begin with 
	mybegin = (myrange * myrank) + (max%numprocs);
    }
    	
    myend = mybegin + myrange; // eh o primeiro nr do proximo range

    if (myrank == 0)
    {
	mybegin = 1; // zero is not a perfect number
    }
    
//    printf("myrank=%d, mybegin=%d, my-end=%d\n", myrank, mybegin, myend);
//    fflush(0);
    
    for (i = mybegin; i < myend; i++)
    {
	    soma = 0;
            for (j = 1; j < i; j++)
	    {
                if(i%j == 0)
		{
                    soma += j;
                }
            }
            if (soma == i)
            {
               numperf[quantnumperf]=i;
               quantnumperf++;
            }
    }

    // creating array for gathering local totals of perfect numbers
    localamounts = (int *) malloc(numprocs*sizeof(int));
    // creating array to shift the gathering of local perfectnumbers by MPI_Gatherv
    vetdisplacements = (int *) malloc(numprocs*sizeof(int));

    
    // recouver local amounts of perfect number. Thay are required to gather local lists of perfect number
    recvcount = sendcount = 1; // mand um total local por processo mpi
    gatherroot = 0;
    MPI_Gather(&quantnumperf, sendcount, MPI_INT, localamounts, recvcount, MPI_INT, gatherroot, MPI_COMM_WORLD);

    //gatherrecvbuf
    
    shift = 0;
    totalnumperf = 0;
    if (myrank == 0)
    {
      // starting in 1 because myrank == 0 is already summed
      for(i=0; i < numprocs; i++)
      {
	  //printf("localamounts[%d]=%d\n", i, localamounts[i]);
	  //fflush(0);
	  totalnumperf+=localamounts[i];
	  vetdisplacements[i]=shift;
	  shift+=localamounts[i];
      }
    }

    // creating array for gathering local perfect numbers
    vetnumperf = (int *) malloc(totalnumperf*sizeof(int));
    
    // para uma consulta ao envio de elementos nulos na funcao MPI_Gatherv veja:
    // https://stackoverflow.com/questions/58577544/use-of-mpi-gatherv-where-the-root-has-no-send-buffer
    MPI_Gatherv(numperf, quantnumperf, MPI_INT, vetnumperf, localamounts, vetdisplacements, MPI_INT, gatherroot, MPI_COMM_WORLD);
    /*
    for(i=0; i<quantnumperf; i++)
    {
        printf("myrank=%d, numperf[%d]=%d. ", myrank, i, numperf[i]);
    }
    */
    
    if(myrank == 0)
    {
      printf("Total perfect numbers:%d\n", totalnumperf);
      fflush(0);
      for(i=0; i<totalnumperf; i++)
      {
	printf("%d\n", vetnumperf[i]);
      }
      printf("\n");
      fflush(0);
    }
        
    MPI_Finalize();
    
    return 0;
    
}
