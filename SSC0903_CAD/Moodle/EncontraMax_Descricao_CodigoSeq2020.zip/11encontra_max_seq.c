// to compile: gcc 11encontra_max_seq.c -o mainseq -fopenmp
// to execute: mainseq <num_elements>

#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

int main(int argc,char **argv)
{
    int *vetor,i,maior=0,tam;

    double wtime;

    if ( argc  != 2)
    {
	printf("Wrong arguments. Please use main <amount_of_elements>\n");
	exit(0);
    }

    tam = atoi(argv[1]);
    //tam = 90000000;   // 90M
    //tam = 10

    printf("Amount of vetor=%d\n", tam);
    fflush(0);

    vetor=(int*)malloc(tam*sizeof(int)); //Aloca o vetor da dimensão lida

    // getting start time after malloc.
    wtime = omp_get_wtime();


    // iniciando vetor com nrs aleatorios e fixando o maior valor para validacao
    for(i=0; i<tam; i++)
    {
//        vetor[i] = rand() % 10000;
		vetor[i] = tam - i;
    }
    vetor[tam/2] = 10001;

//    wtime = omp_get_wtime() - wtime;
//    printf("SEQ: Elapsed wall clock time = %f \n", wtime);

    // getting start time after malloc.
//    wtime = omp_get_wtime();
    
    maior=vetor[0];
    for(i=1; i<tam; i++)
    {
        if(vetor[i]>maior)
	{
            maior=vetor[i];
	}
    }

    wtime = omp_get_wtime() - wtime;

/*   // imprimindo o vetor para conferencia
    for(i = 0; i < tam; i++)
    {
	printf("vetor[%d]=%d\n",i,vetor[i]);
    }
    printf("\n");
*/    
    printf("Tam=%d, maior=%d\nElapsed wall clock time = %f \n", tam, maior, wtime);
    free(vetor); //Desaloca o vetor lido
    
    return 0;
    
}
