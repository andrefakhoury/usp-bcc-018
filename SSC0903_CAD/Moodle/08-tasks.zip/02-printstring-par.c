/*
Há duas threads executando e imprimindo as strings.

As saídas abaixo são possíveis:
A race car A race car   (é o usual)
A A race car race car   (é possível)
A A race race car car   (é possível)

*/

#include <stdlib.h>
#include <stdio.h>
#include <omp.h>

int main(int argc, char *argv[]) 
{
    #pragma omp parallel num_threads(2)
    {
      printf("A ");
      fflush(0);
      printf("race ");
      fflush(0);
      printf("car ");
      fflush(0);
      
    } // End of parallel region
    
    printf("\n");

    return(0);

}