/*
Código sequencial:

A saída abaixo é a possível:
A race car 

*/

#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
	printf("A ");
	printf("race ");
	printf("car ");
	printf("\n");
	
	return(0);
	
}